from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    author="mcatal-d",
    author_email="mcatal-d@student.42.fr",
    description="A sample test package",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
    url="https://github.com/eagle/ft_package",
)
