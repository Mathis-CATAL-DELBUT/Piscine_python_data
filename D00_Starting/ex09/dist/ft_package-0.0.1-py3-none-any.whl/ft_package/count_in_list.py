def count_in_list(lst, value):
    """
    Count the number of occurrences of a value in a list.
    """
    return lst.count(value)
